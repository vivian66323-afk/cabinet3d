/* Gemini 與 ChatGPT 網頁的選擇器。改版找不到欄位時只要改這裡，
   然後到 chrome://extensions 按這個擴充功能的「重新載入」。
   由上往下試，第一個找到的就用。

   這兩套清單和 SketchUp 外掛的 gemini_selectors.json / chatgpt_selectors.json 內容相同，
   但兩邊各自獨立，改了一邊要記得改另一邊。 */
var AW_SITES = {
  gemini: {
    name: 'Gemini',
    host: 'gemini.google.com',
    editor: [
      "rich-textarea div.ql-editor[contenteditable='true']",
      "div.ql-editor[contenteditable='true']",
      "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true'][aria-label]",
      "div[contenteditable='true']"
    ],
    fileInput: ["input[type=file][multiple]", "input[type=file][accept*='image']", "input[type=file]"],
    uploadButton: [
      "uploader-button-wrapper button",
      "button[aria-label*='上傳']",
      "button[aria-label*='新增檔案']",
      "button[aria-label*='附加']",
      "button[aria-label*='Upload']",
      "button[aria-label*='upload']",
      "button[aria-label*='Add files']",
      "button[aria-label*='Open upload']"
    ],
    menuText: ['上傳檔案', '上傳圖片', '新增檔案', '從裝置上傳', 'Upload files', 'Upload file', 'Add files'],
    sendButton: [
      "button.send-button",
      "button[aria-label='傳送']",
      "button[aria-label*='傳送']",
      "button[aria-label*='送出']",
      "button[aria-label*='Send message']",
      "button[aria-label*='Send']"
    ],
    chip: [
      "uploader-file-preview img",
      "xap-filled-thumbnail img",
      "[data-test-id='file-preview'] img",
      ".file-preview img"
    ]
  },

  chatgpt: {
    name: 'ChatGPT',
    host: 'chatgpt.com',
    editor: [
      "div#prompt-textarea[contenteditable='true']",
      "#prompt-textarea",
      "div.ProseMirror[contenteditable='true']",
      "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true']"
    ],
    fileInput: ["input[type=file][multiple]", "input[type=file][accept*='image']", "input[type=file]"],
    uploadButton: [
      "button[data-testid='composer-plus-btn']",
      "button[aria-label*='附加']",
      "button[aria-label*='上傳']",
      "button[aria-label*='新增']",
      "button[aria-label*='Attach']",
      "button[aria-label*='Upload']",
      "button[aria-label*='Add photos']"
    ],
    menuText: ['新增相片和檔案', '上傳檔案', '從電腦上傳', '新增照片和檔案',
               'Add photos and files', 'Upload from computer', 'Upload file'],
    sendButton: [
      "button[data-testid='send-button']",
      "button[aria-label*='傳送']",
      "button[aria-label*='送出']",
      "button[aria-label*='Send prompt']",
      "button[aria-label*='Send message']"
    ],
    chip: [
      "div[data-testid='composer-attachment'] img",
      "div[class*='composer'] img[alt]",
      "button[aria-label*='附件'] img",
      "img[alt*='已上傳']"
    ]
  }
};

/* 依目前網址判斷是哪一邊 */
var AW_SEL = (function () {
  for (const k in AW_SITES) {
    if (location.host.indexOf(AW_SITES[k].host) >= 0) return AW_SITES[k];
  }
  return AW_SITES.gemini;
})();
