/* 背景程式:收下網頁送來的圖與提示詞,開(或沿用)一個 Gemini 分頁,
   等那邊的 content script 說「我好了」再把東西交給它。

   每次都導到 https://gemini.google.com/app 開「新對話」:沿用舊對話的話,
   歷次送的圖會一直疊在上下文裡,Gemini 會改用文字分析回答而不生圖。 */

/* 每個服務各自的新對話網址與分頁比對字串 */
const SITES = {
  gemini:  { url: 'https://gemini.google.com/app', match: 'https://gemini.google.com/*', name: 'Gemini' },
  chatgpt: { url: 'https://chatgpt.com/',          match: 'https://chatgpt.com/*',       name: 'ChatGPT' }
};
let pending = null;          // { payload, fromTabId, tabId }

function status(stage, text, ok) {
  if (!pending || pending.fromTabId == null) return;
  chrome.tabs.sendMessage(pending.fromTabId, { type: 'AW_STATUS', stage, text, ok }, () => void chrome.runtime.lastError);
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;

  if (msg.type === 'AW_SEND') {
    const n = (msg.payload.images || []).length;
    if (!n) { reply({ ok: false, error: '沒有圖片' }); return; }
    pending = { payload: msg.payload, fromTabId: sender.tab && sender.tab.id, tabId: null };
    openSite();
    reply({ ok: true });
    return;
  }

  // Gemini 分頁的 content script 載好後會來要資料
  if (msg.type === 'AW_READY') {
    const tid = sender.tab && sender.tab.id;
    if (pending && pending.tabId === tid && pending.payload) {
      const p = pending.payload;
      pending.payload = null;                 // 只交一次,避免重新整理又送一輪
      reply({ payload: p });
    } else {
      reply({ payload: null });
    }
    return true;
  }

  if (msg.type === 'AW_RESULT') {
    status(msg.ok ? 'done' : 'error', msg.text, msg.ok);
    return;
  }
});

async function openSite() {
  const site = SITES[(pending.payload && pending.payload.service) || 'gemini'] || SITES.gemini;
  status('opening', '正在開啟 ' + site.name + '…', true);
  const tabs = await chrome.tabs.query({ url: site.match });
  let tab;
  if (tabs.length) {
    tab = await chrome.tabs.update(tabs[0].id, { url: site.url, active: true });
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  } else {
    tab = await chrome.tabs.create({ url: site.url, active: true });
  }
  pending.tabId = tab.id;
  status('opened', '已開啟 ' + site.name + ',等待頁面載入…', true);
}
