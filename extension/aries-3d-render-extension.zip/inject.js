/* 跑在 gemini.google.com 或 chatgpt.com 上:把圖塞進檔案欄、提示詞打進輸入框、按送出。
   兩邊的差別全部收在 selectors.js 的 AW_SITES 裡,這支程式本身不分服務。
   做的事和 SketchUp 外掛那支 gemini_cdp.ps1 一樣,只是改用 content script 的身分執行。 */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const pick = list => {
    for (const s of list || []) {
      let e = null;
      try { e = document.querySelector(s); } catch (err) { e = null; }
      if (e) return e;
    }
    return null;
  };

  /* ---- 畫面上的小提示條 ---- */
  let bar;
  function note(text, kind) {
    if (!bar) {
      bar = document.createElement('div');
      bar.style.cssText = 'position:fixed;top:14px;right:14px;z-index:2147483647;max-width:340px;' +
        'padding:10px 14px;border-radius:8px;font:13px/1.5 "Microsoft JhengHei",sans-serif;' +
        'box-shadow:0 6px 24px rgba(0,0,0,.25);white-space:pre-wrap';
      document.documentElement.appendChild(bar);
    }
    const c = { run: ['#eef3fb', '#24456e'], ok: ['#eaf6ef', '#1f7a4d'], err: ['#fdeeee', '#9b2c2c'] }[kind || 'run'];
    bar.style.background = c[0];
    bar.style.color = c[1];
    bar.textContent = 'Aries:' + text;
    if (kind === 'ok') setTimeout(() => { if (bar) bar.remove(), (bar = null); }, 6000);
  }

  function done(ok, text) {
    note(text, ok ? 'ok' : 'err');
    chrome.runtime.sendMessage({ type: 'AW_RESULT', ok, text }, () => void chrome.runtime.lastError);
  }

  function dataURLToFile(url, name) {
    const i = url.indexOf(',');
    const mime = (url.slice(0, i).match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
    const bin = atob(url.slice(i + 1));
    const arr = new Uint8Array(bin.length);
    for (let k = 0; k < bin.length; k++) arr[k] = bin.charCodeAt(k);
    return new File([arr], name, { type: mime });
  }

  async function waitFor(fn, ms, step) {
    const end = Date.now() + ms;
    for (;;) {
      const v = fn();
      if (v) return v;
      if (Date.now() > end) return null;
      await sleep(step || 400);
    }
  }

  /* 用文字找選單項目:同一段文字會從外層容器重複到最內層,
     只挑「子孫裡沒有同樣文字」的那個,不然會點到整個選單外框而沒反應。 */
  function clickByText(texts) {
    for (const want of texts || []) {
      const all = document.querySelectorAll('button,[role=menuitem],[role=option],li,a,span,div');
      for (const el of all) {
        const s = (el.innerText || el.textContent || '').trim();
        if (!s || s.length > 40 || s.indexOf(want) < 0) continue;
        let deeper = false;
        for (const kid of el.querySelectorAll('*')) {
          const ks = (kid.innerText || kid.textContent || '').trim();
          if (ks && ks.indexOf(want) >= 0) { deeper = true; break; }
        }
        if (deeper) continue;
        (el.closest('[role=menuitem],[role=option],button,li,a') || el).click();
        return want;
      }
    }
    return null;
  }

  function chipCount() {
    let n = 0;
    for (const s of AW_SEL.chip) {
      try { n = Math.max(n, document.querySelectorAll(s).length); } catch (e) { /* 忽略 */ }
    }
    return n;
  }

  async function run(payload) {
    const imgs = payload.images || [];
    note('準備送 ' + imgs.length + ' 張圖…');

    if (location.host.indexOf('accounts.google.com') >= 0 || location.host.indexOf('auth.openai.com') >= 0) {
      done(false, '這個瀏覽器還沒登入 ' + AW_SEL.name + ',請先登入再回網站按一次。');
      return;
    }

    const ed = await waitFor(() => pick(AW_SEL.editor), 60000);
    if (!ed) { done(false, '找不到 ' + AW_SEL.name + ' 的輸入框(可能改版了,請更新擴充功能的 selectors.js)'); return; }

    // 1. 檔案欄:通常藏在「＋ / 上傳檔案」選單裡,先點開
    let input = pick(AW_SEL.fileInput);
    if (!input) {
      note('開啟上傳選單…');
      const b = pick(AW_SEL.uploadButton);
      if (b) b.click();
      await sleep(900);
      input = pick(AW_SEL.fileInput);
      if (!input) {
        clickByText(AW_SEL.menuText);
        input = await waitFor(() => pick(AW_SEL.fileInput), 12000);
      }
    }
    if (!input) { done(false, '找不到檔案上傳欄,圖沒有送出去。'); return; }

    // 2. 塞檔案(和使用者自己拖進去是同一條路徑:change 事件)
    note('上傳 ' + imgs.length + ' 張圖…');
    const files = imgs.map((im, i) => dataURLToFile(im.url, im.name || ('image' + (i + 1) + '.jpg')));
    const dt = new DataTransfer();
    files.forEach(f => dt.items.add(f));
    try {
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) { done(false, '塞檔案失敗:' + e.message); return; }

    // 3. 等縮圖長出來才算上傳完成(數不到就只回報,不當失敗)
    const got = await waitFor(() => (chipCount() >= files.length ? chipCount() : 0), 120000, 800);
    if (!got) note('縮圖只看到 ' + chipCount() + ' / ' + files.length + ' 張,仍繼續…');

    // 4. 提示詞
    note('輸入提示詞…');
    ed.focus();
    ed.click();
    let typed = false;
    try { typed = document.execCommand('insertText', false, payload.prompt); } catch (e) { typed = false; }
    await sleep(300);
    if (!typed || (ed.innerText || '').trim().length < 10) {
      ed.textContent = payload.prompt;
      ed.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: payload.prompt }));
      await sleep(300);
    }
    if ((ed.innerText || '').trim().length < 10) {
      done(false, '提示詞打不進輸入框(圖已上傳),請手動貼上。');
      return;
    }

    // 5. 送出
    if (payload.send === false) { done(true, '圖與提示詞都放好了,確認後自己按送出。'); return; }
    await sleep(600);
    const btn = await waitFor(() => {
      const b = pick(AW_SEL.sendButton);
      return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true' ? b : null;
    }, 20000, 500);
    if (btn) { btn.click(); done(true, '已送出 ' + files.length + ' 張圖 + 提示詞,等 ' + AW_SEL.name + ' 出圖。'); }
    else done(false, '送出鈕一直是停用狀態(可能還在上傳),請自己按一下送出。');
  }

  chrome.runtime.sendMessage({ type: 'AW_READY' }, res => {
    if (chrome.runtime.lastError) return;
    if (res && res.payload) run(res.payload).catch(e => done(false, '發生錯誤:' + e.message));
  });
})();
