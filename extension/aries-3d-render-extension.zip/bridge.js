/* 跑在 3D系統櫃網站上的橋接:
   網頁用 window.postMessage 把圖與提示詞交給這裡,再轉給背景程式。
   content script 與網頁是隔離的兩個 JS 世界,網頁看不到 chrome.*,
   所以用 documentElement 的屬性讓網頁知道「擴充功能裝了沒」。 */
(function () {
  const VER = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '1';
  document.documentElement.setAttribute('data-aw-gemini-ext', VER);

  window.addEventListener('message', ev => {
    if (ev.source !== window) return;                       // 只收同一個分頁自己發的
    const d = ev.data;
    if (!d || d.__aw !== 'gemini-send') return;
    chrome.runtime.sendMessage(
      // service 一定要帶過去,不然背景程式會落回預設的 Gemini
      { type: 'AW_SEND', payload: { images: d.images, prompt: d.prompt, send: !!d.send, service: d.service || 'gemini' } },
      res => {
        const err = chrome.runtime.lastError;
        window.postMessage({
          __aw: 'gemini-ack',
          ok: !err && !!(res && res.ok),
          error: err ? err.message : (res && res.error) || ''
        }, '*');
      }
    );
  });

  // 背景程式回報進度 → 轉給網頁(網頁可以顯示狀態)
  chrome.runtime.onMessage.addListener(msg => {
    if (msg && msg.type === 'AW_STATUS') {
      window.postMessage({ __aw: 'gemini-status', stage: msg.stage, text: msg.text, ok: msg.ok }, '*');
    }
  });
})();
