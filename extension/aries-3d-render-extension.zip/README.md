# Aries 系統櫃 → Gemini / ChatGPT 自動送圖（Chrome 擴充功能）

讓 3D系統櫃網站的「3D渲染」變成**全自動**：自動開新對話、上傳三張控制圖、貼上提示詞、按送出。
送到 **Gemini** 或 **ChatGPT** 都可以（在面板上的「送到」選），用的是網頁的免費額度，
**不需要 API 金鑰**。

> 為什麼非得裝擴充功能？瀏覽器的同源政策禁止一個網站去操作另一個網站（gemini.google.com、
> chatgpt.com）的頁面，所以網頁本身做不到自動上傳。擴充功能的 content script 是跑在 Gemini 頁面裡面的，
> 才有這個權限 —— 和 SketchUp 外掛用 DevTools Protocol 驅動 Chrome 是同樣的道理。

## 安裝（每台電腦做一次，約 30 秒）

1. Chrome 網址列輸入 `chrome://extensions`
2. 右上角打開「**開發人員模式**」
3. 點左上角「**載入未封裝項目**」
4. 選擇這個 `chrome-extension` 資料夾（就是放著 `manifest.json` 的這一層）
5. 回到 3D系統櫃網站**重新整理一次**，按「3D渲染」，面板上就會多一顆
   「**送進 Gemini／ChatGPT 並自動生圖**」

第一次使用前，請先在這個 Chrome 登入要用的服務：Gemini 用 Google 帳號、ChatGPT 用 OpenAI 帳號。

> **更新擴充功能後**（例如我改了 `selectors.js` 或新增服務），要到 `chrome://extensions`
> 按這個擴充功能的「**重新載入**」，新版才會生效。

## 用法

網站 →「3D渲染」→ 選「送到 Gemini／ChatGPT」與風格／燈光／家具 → 按「送進 ○○ 並自動生圖」。
之後會自動切到該服務的分頁，右上角會有進度提示；出圖完成後直接在那邊下載。

ChatGPT 的免費出圖額度每天約 4 張，而且透視比 Gemini 容易被「拉正」，主力建議用 Gemini。

## 檔案

| 檔案 | 做什麼 |
|---|---|
| `manifest.json` | 權限與進入點（MV3） |
| `bridge.js` | 跑在 3D系統櫃網站上，把網頁的 `postMessage` 轉給背景程式；並在 `<html>` 掛上 `data-aw-gemini-ext` 讓網頁知道擴充功能裝好了 |
| `background.js` | 依「送到」開（或沿用）Gemini／ChatGPT 分頁並導到首頁開**新對話**，等那邊要資料時再交出去 |
| `inject.js` | 跑在 Gemini／ChatGPT 頁面裡：點開上傳選單、用 `DataTransfer` 塞檔案、等縮圖、打提示詞、按送出。兩邊共用同一支程式 |
| `selectors.js` | 兩個網站各自的選擇器清單（`AW_SITES`），依網址自動選用 |

## Gemini 改版、按鍵找不到時

只要改 `selectors.js` 裡對應服務那一段：在該頁面按 F12 →選取元素→右鍵 Copy → Copy selector，
貼到對應清單的**最前面**，然後到 `chrome://extensions` 按這個擴充功能的「重新載入」。
不用動其他程式。

每次送圖都會開新對話，這是刻意的：沿用同一個對話的話，歷次的圖會一直疊在上下文裡，
Gemini 會改用文字分析回答而不生圖（實測疊到 13 張就會發生）。
